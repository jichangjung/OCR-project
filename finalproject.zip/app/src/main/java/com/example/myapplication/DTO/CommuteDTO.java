package com.example.myapplication.DTO;

public class CommuteDTO {

    private String employeeNo;
    private String work_on;
    private String work_off;

    public CommuteDTO(String employeeNo,String work_off,String work_on){
        this.employeeNo = employeeNo;
        this.work_off =work_off;
        this.work_on = work_on;
    }

    public String getEmployeeNo() {
        return employeeNo;
    }

    public void setEmployeeNo(String employeeNo) {
        this.employeeNo = employeeNo;
    }

    public String getWork_on() {
        return work_on;
    }

    public void setWork_on(String work_on) {
        this.work_on = work_on;
    }

    public String getWork_off() {
        return work_off;
    }

    public void setWork_off(String work_off) {
        this.work_off = work_off;
    }
}
