package com.example.myapplication.Board;


import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.myapplication.DTO.BoardDTO;
import com.example.myapplication.R;
import com.example.myapplication.RetrofitClient;
import com.example.myapplication.UserRetrofitInterface;
import com.google.gson.Gson;

import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class CreateActivity extends AppCompatActivity {

    private String nickname;

    private BoardRetrofitInterface boardRetrofitInterface;
    Button CreateBtn;
    UserRetrofitInterface userRetrofitInterface;
    Intent intent;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create);


        nickname = getIntent().getStringExtra("nickname");
        boardRetrofitInterface = RetrofitClient.getInstance().getBoardRetrofitInterface();
        EditText titlte = (EditText) findViewById(R.id.title_et);
        EditText Content = (EditText) findViewById(R.id.content_et);
        CreateBtn = (Button) findViewById(R.id.reg_button);

        RetrofitClient retrofitClient = RetrofitClient.getInstance();
        UserRetrofitInterface userRetrofitInterface = RetrofitClient.getUserRetrofitInterface();


        CreateBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String title = titlte.getText().toString();
                String content = Content.getText().toString();

                if (title.trim().isEmpty() || content.trim().isEmpty()) {
                    Toast.makeText(getApplicationContext(), "제목과 내용을 입력해주세요.", Toast.LENGTH_SHORT).show();
                    return;
                }

                BoardDTO boardDto = new BoardDTO(nickname, title, content);
                Gson gson = new Gson();
                String userInfo = gson.toJson(boardDto);

                Log.e("JSON", userInfo);

                Call<ResponseBody> call = boardRetrofitInterface.saveTest(boardDto);
                call.clone().enqueue(new Callback<ResponseBody>() {
                    @Override
                    public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
                        if (response.isSuccessful()) {
                            Log.e("POST", "성공");

                            intent = new Intent(CreateActivity.this, BoardActivity.class);
                            intent.putExtra("nickname", nickname);
                            startActivity(intent);
                            finish();
                            Toast.makeText(getApplicationContext(), "게시글 작성 성공", Toast.LENGTH_SHORT).show();

                        }
                    }

                    @Override
                    public void onFailure(Call<ResponseBody> call, Throwable t) {
                        Log.e("POST", "실패");
                        Toast.makeText(getApplicationContext(), "게시글 작성 실패", Toast.LENGTH_SHORT).show();
                    }
                });
            }
        });

    }

    @Override
    public void onBackPressed() {
         intent = new Intent(CreateActivity.this, BoardActivity.class);
        intent.putExtra("nickname", nickname);
        startActivity(intent);
        finish();
        super.onBackPressed();
    }
}