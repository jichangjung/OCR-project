package com.example.myapplication.Board;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.myapplication.Board.BoardRetrofitInterface;
import com.example.myapplication.MainActivity;
import com.example.myapplication.R;
import com.example.myapplication.RetrofitClient;
import com.example.myapplication.DTO.BoardDTO;

import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class UpdatePostActivity extends AppCompatActivity {

    private TextView titleTextView;
    private TextView contentTextView;
    private TextView nicknameTextView; // 닉네임을 표시할 TextView
    private TextView dateTextView;

    private EditText editContentEditText;

    private Button deleteBtn, updateBtn;

    private String nickname;

    private BoardRetrofitInterface boardRetrofitInterface;
    private static final String TAG = "UpdatePostActivity";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_post);
        Log.i(TAG, "onCreate: gj");
        boardRetrofitInterface = RetrofitClient.getInstance().getBoardRetrofitInterface();
        nickname = getIntent().getStringExtra("nickname");
        titleTextView = findViewById(R.id.title_tv);
        contentTextView = findViewById(R.id.content_tv);
//        nicknameTextView = findViewById(R.id.nickname);
        dateTextView = findViewById(R.id.nick);
        deleteBtn = findViewById(R.id.reg_delete);
        updateBtn = findViewById(R.id.reg_change);


        int postidx = getIntent().getIntExtra("post_idx", 0);
        String postTitle = getIntent().getStringExtra("post_title");
        String postContent = getIntent().getStringExtra("post_content");
        String postNickname = getIntent().getStringExtra("post_nickname"); // 닉네임 정보 가져오기
        String postDate = getIntent().getStringExtra("post_date"); // 날짜 정보 가져오기

        titleTextView.setText(postTitle);
        contentTextView.setText(postContent);
        dateTextView.setText(postNickname); // 닉네임 설정
        // 날짜 설정

        deleteBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // 게시물 삭제 요청을 서버로 보냅니다.
                int postIdx = 123;

                Call<ResponseBody> call = boardRetrofitInterface.deleteBoard(postidx);
                call.enqueue(new Callback<ResponseBody>() {
                    @Override
                    public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
                        if (response.isSuccessful()) {
                            // 서버 응답이 성공적으로 돌아온 경우
                            // 삭제 완료 메시지나 다른 작업 수행
                            Log.d("DeletePost", "게시글이 성공적으로 삭제되었습니다.");

                            // Show a success toast message
                            Toast.makeText(UpdatePostActivity.this, "게시글이 성공적으로 삭제되었습니다.", Toast.LENGTH_SHORT).show();

                            Intent intent = new Intent(UpdatePostActivity.this, BoardActivity.class);
                            intent.putExtra("nickname", nickname);
                            startActivity(intent);
                            finish();
                            // 게시글 삭제 후 필요한 작업 수행 (예: 화면 갱신, 목록으로 이동 등)
                        } else {
                            // 서버 응답이 실패한 경우
                            Log.e("DeletePost", "게시글 삭제 실패: " + response.message());
                        }

                    }

                    @Override
                    public void onFailure(Call<ResponseBody> call, Throwable t) {
                        // 통신 실패 시
                        Log.e("DeletePost", "게시글 삭제 요청 실패: " + t.getMessage());
                    }
                });
            }
        });

        updateBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // 수정할 내용을 가져옴
                String newTitle = titleTextView.getText().toString();
                String newContent = contentTextView.getText().toString();
                // 다른 수정할 내용들도 가져와서 필요한 데이터를 준비

                // BoardDTO 객체를 생성하여 수정할 내용을 담음
                BoardDTO updatedBoard = new BoardDTO(postidx, postTitle, postContent, postNickname);
                updatedBoard.setTitle(newTitle);
                updatedBoard.setContent(newContent);
                // 다른 필드도 필요한 대로 설정

                // 서버로 업데이트 요청 보내기
                Call<ResponseBody> call = boardRetrofitInterface.updateBoard(updatedBoard);
                call.enqueue(new Callback<ResponseBody>() {
                    @Override
                    public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
                        if (response.isSuccessful()) {
                            // 서버 응답이 성공적으로 돌아온 경우
                            // 수정 완료 메시지나 다른 작업 수행
                            Log.d("UpdatePost", "게시글이 성공적으로 수정되었습니다.");
                            Intent intent = new Intent(UpdatePostActivity.this, ViewPostActivity.class);
                            intent.putExtra("nickname", nickname);
                            intent.putExtra("post_idx", postidx);
                            intent.putExtra("post_title", titleTextView.getText().toString());
                            intent.putExtra("post_content", contentTextView.getText().toString());
                            intent.putExtra("post_nickname", postNickname);
                            startActivity(intent);
                            finish();
                        } else {
                            // 서버 응답이 실패한 경우
                            Log.e("UpdatePost", "게시글 수정 실패: " + response.message());
                        }
                    }

                    @Override
                    public void onFailure(Call<ResponseBody> call, Throwable t) {
                        // 통신 실패 시
                        Log.e("UpdatePost", "게시글 수정 요청 실패: " + t.getMessage());
                    }
                });
            }
        });

//        getBoardDetails();
    }

    //    private void getBoardDetails(Long idx) {
//        Call<BoardDTO> call = boardRetrofitInterface.getBoardDetails(idx);
//
//        call.enqueue(new Callback<BoardDTO>() {
//            @Override
//            public void onResponse(Call<BoardDTO> call, Response<BoardDTO> response) {
//
//                if (response.isSuccessful() && response.body() != null) {
//                    List<BoardDTO> boards = response.body();
//                    originalPostList.clear();
//
//                    for (BoardDTO board : boards) {
//                        originalPostList.add(board.getTitle());
//                    }
//                    Log.e("callData",originalPostList.toString());
//                    updateListView(searchEditText.getText().toString());
//                }
//            }
//
//            @Override
//            public void onFailure(Call<List<BoardDTO>> call, Throwable t) {
//                // Handle communication failure
//                Log.e("failure", t.getMessage());
//            }
//        });
//    }
}
