package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.util.Log;
import android.widget.Toast;

import com.example.myapplication.DTO.JoinDTO;

import org.json.JSONObject;

import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class JoinActivity extends AppCompatActivity {

    UserRetrofitInterface userRetrofitInterface;
    Button duplicateCheckButton,check_button;
    EditText joinEmp,joinNickname,joinPassword,joinPwck;
    Intent intent;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_join);

        RetrofitClient retrofitClient = RetrofitClient.getInstance();
        userRetrofitInterface = RetrofitClient.getUserRetrofitInterface();

        duplicateCheckButton = findViewById(R.id.check_button);
        Button Join = findViewById(R.id.join_button);
        Button Cancel = findViewById(R.id.cancel);


        joinEmp = findViewById(R.id.join_emp);
        joinPassword = findViewById(R.id.join_password);
        joinPwck = findViewById(R.id.join_pwck);
        joinNickname = findViewById(R.id.join_nickname);
        check_button = findViewById(R.id.check_button);

        intent = new Intent(JoinActivity.this, MainActivity.class);
        // 중복 확인 버튼을 누를 때
        check_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // 사용자가 입력한 닉네임 가져오기
                String check = joinNickname.getText().toString();
                JoinDTO joinDTO = new JoinDTO(check);

                // Retrofit으로 서버에 중복 체크 요청 보내기
                Call<ResponseBody> checkDuplicateIdCall = userRetrofitInterface.checkDuplicateId(joinDTO);

                checkDuplicateIdCall.enqueue(new Callback<ResponseBody>() {
                    @Override
                    public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
                        if (response.isSuccessful()) {
                            try {
                                // 서버에서 JSON 응답 데이터를 파싱
                                JSONObject jsonResponse = new JSONObject(response.body().string());
                                boolean isDuplicate = jsonResponse.getBoolean("isDuplicate");

                                if (isDuplicate) {
                                    // 서버에서 ID가 중복됨 (이미 사용 중)
                                    Toast.makeText(JoinActivity.this, "이미 사용 중인 ID입니다.", Toast.LENGTH_SHORT).show();
                                } else {
                                    // 서버에서 ID가 중복되지 않음 (사용 가능)
                                    Toast.makeText(JoinActivity.this, "사용 가능한 ID입니다.", Toast.LENGTH_SHORT).show();
                                }
                            } catch (Exception e) {
                                Log.e("CheckDuplicateId", "JSON 파싱 실패: " + e.getMessage());

                            }
                        } else {
                            Log.e("CheckDuplicateId", "서버 응답 실패");
                        }
                    }

                    @Override
                    public void onFailure(Call<ResponseBody> call, Throwable t) {
                        Log.e("CheckDuplicateId", "서버 통신 실패: " + t.getMessage());
                    }
                });
            }
        });





        Cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent cancel = new Intent(JoinActivity.this, MainActivity.class);
                startActivity(cancel);
                finish();
            }
        });

        Join.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String userEmp = joinEmp.getText().toString();
                String userPassword = joinPassword.getText().toString();
                String userPwck = joinPwck.getText().toString();
                String userNickname = joinNickname.getText().toString();

                // 비밀번호와 비밀번호 확인이 일치하는지 확인
                if (!userPassword.equals(userPwck)) {
                    // 비밀번호와 비밀번호 확인이 일치하지 않을 때 처리
                    Toast.makeText(JoinActivity.this, "비밀번호가 일치하지 않습니다.", Toast.LENGTH_SHORT).show();
                    return;
                }

                JoinDTO joinDTO = new JoinDTO(userEmp, userNickname, userPassword);

                // Retrofit을 사용하여 서버로 데이터를 보내는 코드
                Call<ResponseBody> joinCall = userRetrofitInterface.saveUser(joinDTO);
                joinCall.enqueue(new Callback<ResponseBody>() {
                    @Override
                    public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
                        Log.d("Test", response.toString());
                        if (response.isSuccessful()) {
                            // 회원가입 성공
                            Toast.makeText(JoinActivity.this, "회원가입 성공", Toast.LENGTH_SHORT).show();

                            // 회원가입 성공 시 메인 페이지로 이동
                            startActivity(intent);

                            finish(); // JoinActivity를 닫음
                        } else {
                            // 회원가입 실패
                            Log.e("POST", "회원가입 실패");
                            Toast.makeText(JoinActivity.this, "존재하지 않는 직원번호이거나 해당 직원번호는 아이디가 존재합니다.", Toast.LENGTH_SHORT).show();
                            // 실패에 대한 처리 (예: 이미 사용 중인 닉네임 등)
                        }
                    }

                    @Override
                    public void onFailure(Call<ResponseBody> call, Throwable t) {
                        Log.e("POST", "실패");
                    }
                });

            }
        });
    }

    @Override
    public void onBackPressed() {
        startActivity(intent);
        finish();
        super.onBackPressed();
    }
}
