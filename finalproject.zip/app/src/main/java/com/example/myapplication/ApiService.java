package com.example.myapplication;

import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Multipart;
import retrofit2.http.POST;
import retrofit2.http.Part;

public interface ApiService {
    @Multipart
    @POST("upload") // 서버의 업로드 엔드포인트 URL을 여기에 입력
    Call<ResponseBody> uploadImage(@Part MultipartBody.Part image);

    // 텍스트 파일 다운로드 엔드포인트
    @GET("get_text_file")
    Call<ResponseBody> getTextFile();

    Call<Void> uploadText(RequestBody requestBody);

    Call<ResponseBody> registerCheckIn(RequestBody requestBody);
}
