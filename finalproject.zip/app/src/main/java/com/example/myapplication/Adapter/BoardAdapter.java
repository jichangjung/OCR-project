package com.example.myapplication.Adapter;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;

import com.example.myapplication.R;
import com.example.myapplication.DTO.BoardDTO;

import java.util.ArrayList;

public class BoardAdapter extends BaseAdapter {

    Context context;
    ArrayList<BoardDTO> list;

    public BoardAdapter(Context context, ArrayList<BoardDTO> list){
        this.context = context;
        this.list = list;
    }

    public void addDTO(BoardDTO dto){
        list.add(dto);
    }

    public void delDTO(int position){
        list.remove(position);
    }

    @Override
    public int getCount(){
        return list.size();
    }

    @Override
    public BoardDTO getItem(int position){
        return list.get(position);
    }

    @Override
    public long getItemId(int position){
        return position;
    }

    public long getItemIdx(int position){
        BoardDTO dto = list.get(position);

        return dto.getIdx();
    }

    @NonNull
    @Override
    public View getView(final int position, View convertView, ViewGroup parent){
        BoardViewHolder viewHolder;
        LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);

        if(convertView == null){
            convertView = inflater.inflate(R.layout.boardview, parent, false);
            viewHolder = new BoardViewHolder();
            viewHolder.title = convertView.findViewById(R.id.title);

            convertView.setTag(viewHolder);
        }else{
            viewHolder = (BoardViewHolder) convertView.getTag();
        }

        BoardDTO dto = list.get(position);

        Log.d("test", dto.getTitle());

        TextView title = (TextView)convertView.findViewById(R.id.title);
        title.setText(dto.getTitle());

//        viewHolder.title.setText(dto.getTitle());

        return convertView;
    }

    public class BoardViewHolder{
        TextView title;
    }
}
