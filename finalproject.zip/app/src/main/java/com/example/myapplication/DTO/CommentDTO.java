package com.example.myapplication.DTO;

public class CommentDTO {



    private String commentRegDate;
    private Long no;

    private int commentId;

    private Long parentsCommentId;

    private int boardIdx;

    private String commentNickname;

    private String content;

    private String myNickname;

    public void setMyNickName(String name){
        this.myNickname = name;
    }

    public String getMyNickname(){return myNickname;}

    public Long getNo() {
        return no;
    }

    public void setNo(Long no) {
        this.no = no;
    }

    public int getCommentId() {
        return commentId;
    }

    public void setCommentId(int commentId) {
        this.commentId = commentId;
    }

    public Long getParentsCommentId() {
        return parentsCommentId;
    }

    public void setParentsCommentId(Long parentsCommentId) {
        this.parentsCommentId = parentsCommentId;
    }
    public void setCommentRegDate(String commentRegDate) {
        this.commentRegDate = commentRegDate;
    }
    public int getBoardIdx() {
        return boardIdx;
    }

    public void setBoardIdx(int boardIdx) {
        this.boardIdx = boardIdx;
    }

    public String getCommentNickname() {
        return commentNickname;
    }

    public void setCommentNickname(String commentNickname) {
        this.commentNickname = commentNickname;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public CommentDTO(String content) {
        this.commentId = commentId;
        this.content = content;
    }

    public CommentDTO(int commentId, int boardIdx, String commentNickname) {
        this.commentId = commentId;
        this.boardIdx = boardIdx;
        this.commentNickname = commentNickname;
    }

    public void setNickname(String commentNickname, int boardIdx) {
        this.commentNickname =commentNickname;
        this.boardIdx =boardIdx;
    }

    public String getCommentRegDate(){return commentRegDate;}
}

