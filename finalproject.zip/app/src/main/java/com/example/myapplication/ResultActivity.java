package com.example.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;

public class ResultActivity extends AppCompatActivity {

    Button movemain;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_result);

        // 텍스트 파일을 읽고 표시할 TextView를 찾습니다.
        TextView textView = findViewById(R.id.resultTextView);
        movemain =findViewById(R.id.movemain);

        // txt 파일을 읽어서 TextView에 표시합니다.
        displayDownloadedText(textView);
        Log.d("ocrtext",textView.toString());

        Toast.makeText(this, "출/퇴근 완료됐습니다!", Toast.LENGTH_SHORT).show();

        movemain.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ResultActivity.this,MainActivity.class);
                startActivity(intent);
                finish();

            }
        });



    }

    // 다운로드한 텍스트 파일을 TextView에 설정
    private void displayDownloadedText(TextView textView) {
        try {
            // 내부 저장소의 앱 디렉토리에서 txt 파일 읽기
            File dir = getFilesDir(); // 앱의 내부 저장소 디렉토리
            File textFile = new File(dir, "extracted_text.txt");

            StringBuilder text = new StringBuilder();
            BufferedReader br = new BufferedReader(new FileReader(textFile));
            String line;

            while ((line = br.readLine()) != null) {
                text.append(line);
                text.append('\n');
            }
            br.close();

            // TextView에 텍스트 설정
            textView.setText(text.toString());
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    public void onBackPressed() {
        Intent intent =new Intent(ResultActivity.this, MainActivity.class);
        startActivity(intent);
        finish();
        super.onBackPressed();
    }
}