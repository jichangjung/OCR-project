package com.example.myapplication.DTO;

public class BoardDTO {
    public int		idx;
    public String 	nickname;
    public String	title;
    public String 	content;
    public String 	filename;

    public String   deleteYn;



    public BoardDTO() {

    }

    public BoardDTO(String nickname,String title, String content) {
        this.nickname=nickname;
        this.title = title;
        this.content = content;
    }

    public BoardDTO(int idx, String nickname, String content, String title) {
        this.idx = idx;
        this.nickname = nickname;
        this.content = content;
        this.title = title;
    }
    // 다른 필드에 대한 getter 및 setter

    public int getIdx() {
        return idx;
    }

    public void setIdx(int idx) {
        this.idx = idx;
    }

    public String getNickname() {
        return nickname;
    }

    public void setNickname(String nickname) {
        this.nickname = nickname;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }
}
