package com.example.myapplication.Board;



import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;

import com.example.myapplication.Adapter.BoardAdapter;
import com.example.myapplication.DTO.BoardDTO;
import com.example.myapplication.R;
import com.example.myapplication.RetrofitClient;
import com.example.myapplication.SelectActivity;
//import com.example.pj.network.BoardRetrofitInterface;

import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import java.util.ArrayList;
import java.util.List;

public class BoardActivity extends AppCompatActivity {
    private ListView listView;
    private BoardAdapter adapter;
    private ArrayList<BoardDTO> originalPostList;
    private List<BoardDTO> filteredPostList = new ArrayList<BoardDTO>();
    private EditText searchEditText; // 검색 기능을 위한 EditText
    private String nickname;
    SharedPreferences sharedPreferences;
    private static final int YOUR_REQUEST_CODE = 1;

    private BoardRetrofitInterface boardRetrofitInterface; // BoardRetrofitInterface 변수 추가

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_board);

        sharedPreferences = getSharedPreferences("UserInfo", MODE_PRIVATE);

        nickname = sharedPreferences.getString("nickname","");


        listView = findViewById(R.id.listview);
        searchEditText = findViewById(R.id.search);

        // Retrofit 초기화
        boardRetrofitInterface = RetrofitClient.getInstance().getBoardRetrofitInterface();

        // 게시물 목록 가져오기
        getBoardList();
        // EditText에서 텍스트가 변경될 때 검색 수행


        // 게시물 클릭 이벤트 처리
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                BoardDTO SelectedBoard = adapter.getItem(position);
                Log.d("title", SelectedBoard.getTitle());
                Log.d("content", SelectedBoard.getContent());
                Log.d("nickname", SelectedBoard.getNickname());


                Intent viewPostIntent = new Intent(BoardActivity.this, ViewPostActivity.class);
                viewPostIntent.putExtra("post_idx",SelectedBoard.getIdx());
                viewPostIntent.putExtra("post_title", SelectedBoard.getTitle());
                viewPostIntent.putExtra("post_content", SelectedBoard.getContent());
                viewPostIntent.putExtra("post_nickname", SelectedBoard.getNickname());
                viewPostIntent.putExtra("nickname", nickname);
                startActivity(viewPostIntent);
                finish();
            }
        });

        // 게시물 작성 버튼 클릭 이벤트 처리
        Button btnCreatePost = findViewById(R.id.btn_create_post);
        btnCreatePost.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                Log.d("CreateActivity", "btnCreatePost clicked");
                Intent intent = new Intent(BoardActivity.this, CreateActivity.class);
                intent.putExtra("nickname", nickname);
                startActivity(intent);
                finish();
            }
        });


        searchEditText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                // 텍스트가 변경되기 전에 수행할 작업
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                // 텍스트가 변경될 때 수행할 작업
                String query = s.toString();
                updateListView(query);
            }

            @Override
            public void afterTextChanged(Editable s) {
                // 텍스트가 변경된 후에 수행할 작업
            }
        });

        // 댓글 목록 가져오기
//        getCommentList();
    }






    // 게시물 목록 가져오기
    private void getBoardList() {
        Call<List<BoardDTO>> call = boardRetrofitInterface.getBoard();

        originalPostList = new ArrayList<>();

        adapter = new BoardAdapter(this, originalPostList);

        call.enqueue(new Callback<List<BoardDTO>>() {
            @Override
            public void onResponse(Call<List<BoardDTO>> call, Response<List<BoardDTO>> response) {

                if (response.isSuccessful() && response.body() != null) {
                    List<BoardDTO> boards = response.body();
                    originalPostList.clear();

                    for (BoardDTO board : boards) {
                        Log.d("board", board.toString());
                        adapter.addDTO(board);
                    }
//                    updateListView(searchEditText.getText().toString());
                    listView.setAdapter(adapter);
//                    adapter.notifyDataSetChanged();
                }
            }

            @Override
            public void onFailure(Call<List<BoardDTO>> call, Throwable t) {
                // Handle communication failure
                Log.e("failure", t.getMessage());
            }
        });
    }

    private void writeBoard(BoardDTO boardData) {
        Call<ResponseBody> call = boardRetrofitInterface.doBoard(boardData);
        call.enqueue(new Callback<ResponseBody>() {
            @Override
            public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
                if (response.isSuccessful()) {
                    // 게시물 작성 성공, 추가적인 로직을 추가하거나 필요한 경우 업데이트
                }
            }

            @Override
            public void onFailure(Call<ResponseBody> call, Throwable t) {
                // Handle communication failure
            }
        });
    }



    // 댓글 목록 가져오기
//    private void getCommentList() {
//        Call<List<CommentDTO>> call = boardRetrofitInterface.getComments();
//        call.enqueue(new Callback<List<CommentDTO>>() {
//            @Override
//            public void onResponse(Call<List<CommentDTO>> call, Response<List<CommentDTO>> response) {
//                if (response.isSuccessful() && response.body() != null) {
//                    List<CommentDTO> comments = response.body();
//
//                    // 댓글 목록을 받아온 후, 각 댓글을 화면에 표시
//                    // 댓글 목록을 받아온 후, 각 댓글을 화면에 표시
//                    for (CommentDTO comment : comments) {
//                        View commentView = getLayoutInflater().inflate(R.layout.reply, null);
//                        TextView userIdTextView = commentView.findViewById(R.id.reply_author_tv);
//                        TextView dateTextView = commentView.findViewById(R.id.reply_date_tv);
//                        TextView contentTextView = commentView.findViewById(R.id.reply_content_tv);
//
//                        userIdTextView.setText(comment.getComment_nickname());
//                        dateTextView.setText(comment.getComment_regdate());
//                        contentTextView.setText(comment.getContent());
//
//                        // replyView를 화면에 추가
//                        LinearLayout replyLayout = findViewById(R.id.reply_layout);
//                        replyLayout.addView(commentView);
//                    }
//                }
//            }
//
//            @Override
//            public void onFailure(Call<List<CommentDTO>> call, Throwable t) {
//                // 통신 실패 처리
//            }
//        });
//    }

    // 게시물 작성 화면에서 결과를 처리

    private void updateListView(String query) {
        filteredPostList.clear();

        for (BoardDTO post : originalPostList) {
            if (post.getTitle().toLowerCase().contains(query.toLowerCase())) {
                filteredPostList.add(post);
            }
        }

        // 필터링된 목록으로 어댑터를 업데이트
        adapter = new BoardAdapter(this, (ArrayList<BoardDTO>) filteredPostList);
        listView.setAdapter(adapter);
    }
}
