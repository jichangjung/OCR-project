package com.example.myapplication.DTO;

public class AndroidWorkDTO {
    private String workOn;
    private String workOff;

    public AndroidWorkDTO(String workOn, String workOff) {
        this.workOn = workOn;
        this.workOff = workOff;
    }

    public String getWorkOn() {
        return workOn;
    }

    public String getWorkOff() {
        return workOff;
    }
}
