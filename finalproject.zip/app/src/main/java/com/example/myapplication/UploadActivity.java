package com.example.myapplication;

import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;

import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class UploadActivity extends AppCompatActivity {
    private static final int PICK_IMAGE_REQUEST = 1;
    private ImageView imageView;
    private Uri imageUri;

    private static final String TAG = "OCR";  // 로그 태그



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_upload);
        imageView = findViewById(R.id.imageView);
    }

    // 이미지 업로드 버튼을 누르면 이미지 선택 창을 엽니다.
    public void uploadImage(View view) {
        Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        intent.setType("image/*");
        startActivityForResult(intent, PICK_IMAGE_REQUEST);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_IMAGE_REQUEST && resultCode == RESULT_OK && data != null && data.getData() != null) {
            imageUri = data.getData();
            imageView.setImageURI(imageUri);
            uploadToServer();
        }
    }

    // 이미지를 서버로 업로드
    private void uploadToServer() {
        ApiService apiService = OCRRetrofitClient.getRetrofitInstance().create(ApiService.class);

        if (imageUri != null) {
            Log.i(TAG, "Image URI Scheme: " + imageUri.getScheme());
            Log.i(TAG, "Sending POST request to server");

            MultipartBody.Part imagePart = prepareFilePart("image", imageUri);

            Call<ResponseBody> call = apiService.uploadImage(imagePart);
            call.enqueue(new Callback<ResponseBody>() {
                @Override
                public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
                    if (response.isSuccessful()) {
                        // 이미지 업로드 성공
                        Log.i(TAG, "Image upload completed");

                        // 이미지 업로드 후, ResultActivity로 이동
                        Intent intent = new Intent(UploadActivity.this, ResultActivity.class);
                        startActivity(intent);
                        finish();

                        overridePendingTransition(0, 0);

                        // 이미지 업로드 후, 서버에서 텍스트 파일 다운로드
                        downloadTextFileFromServer();
                    } else {
                        // 이미지 업로드 실패
                        Log.e(TAG, "Image upload failed");
                        // 오류 처리
                    }
                }

                @Override
                public void onFailure(Call<ResponseBody> call, Throwable t) {
                    // 네트워크 오류 등에 대한 처리
                    Log.e(TAG, "Image upload failed: " + t.getMessage());
                }
            });

        }
    }

    // 이미지 파일을 MultipartBody.Part로 변환
    private MultipartBody.Part prepareFilePart(String partName, Uri fileUri) {
        File file = new File(getRealPathFromURI(fileUri));
        RequestBody requestFile = RequestBody.create(MediaType.parse("multipart/form-data"), file);
        return MultipartBody.Part.createFormData(partName, file.getName(), requestFile);
    }


    // Uri를 사용하여 이미지의 실제 파일 경로를 가져오는 메소드
    private String getRealPathFromURI(Uri uri) {
        String[] projection = {MediaStore.Images.Media.DATA};
        Cursor cursor = getContentResolver().query(uri, projection, null, null, null);
        if (cursor != null) {
            cursor.moveToFirst();
            int columnIndex = cursor.getColumnIndex(projection[0]);
            String filePath = cursor.getString(columnIndex);
            cursor.close();
            return filePath;
        }
        return uri.getPath();
    }


    // 서버로부터 텍스트 파일 다운로드
    private void downloadTextFileFromServer() {
        ApiService apiService = OCRRetrofitClient.getRetrofitInstance().create(ApiService.class);
        Call<ResponseBody> call = apiService.getTextFile();
        call.enqueue(new Callback<ResponseBody>() {
            @Override
            public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
                if (response.isSuccessful()) {
                    try {
                        // 내부 저장소의 앱 디렉토리에 파일 저장
                        File dir = getFilesDir(); // 앱의 내부 저장소 디렉토리
                        File textFile = new File(dir, "extracted_text.txt");

                        InputStream inputStream = response.body().byteStream();
                        FileOutputStream fileOutputStream = new FileOutputStream(textFile);

                        byte[] buffer = new byte[1024];
                        int len;
                        while ((len = inputStream.read(buffer)) != -1) {
                            fileOutputStream.write(buffer, 0, len);
                        }

                        fileOutputStream.close();
                        inputStream.close();

                        // 텍스트 파일을 다운로드한 후 파일을 사용 (예: 파일 내용을 읽거나 표시)
                        // 이 부분에서 텍스트 파일을 읽어 TextView에 설정 가능
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                } else {
                    // 서버로부터 텍스트 파일 다운로드 실패
                    Log.e(TAG, "Failed to download text file from server");
                }
            }

            @Override
            public void onFailure(Call<ResponseBody> call, Throwable t) {
                // 네트워크 오류 등에 대한 처리
                Log.e(TAG, "Failed to download text file from server: " + t.getMessage());
            }
        });
    }

    // 다운로드한 텍스트 파일을 TextView에 설정
    private void displayDownloadedText(File textFile) {
        try {
            StringBuilder text = new StringBuilder();
            BufferedReader br = new BufferedReader(new FileReader(textFile));
            String line;

            while ((line = br.readLine()) != null) {
                text.append(line);
                text.append('\n');
            }
            br.close();

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    public void onBackPressed() {
        Intent intent =new Intent(UploadActivity.this, MainActivity.class);
        startActivity(intent);
        finish();
        super.onBackPressed();
    }
}
