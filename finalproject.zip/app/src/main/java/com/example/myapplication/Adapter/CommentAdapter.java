package com.example.myapplication.Adapter;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.myapplication.DTO.BoardDTO;
import com.example.myapplication.DTO.CommentDTO;
import com.example.myapplication.R;

import java.util.ArrayList;
import java.util.List;

public class CommentAdapter extends BaseAdapter{
//    private List<CommentDTO> commentList; // 댓글 데이터를 저장할 리스트
    public interface ListBtnClickListener{
        void onListBtnClick(int position);
    }
    Context context;
    ArrayList<CommentDTO> list;

    private ListBtnClickListener listbtnclicklistener;

    public CommentAdapter(Context context, ArrayList<CommentDTO> list, ListBtnClickListener clickListener){
        this.context = context;

        this.list = list;

        this.listbtnclicklistener = clickListener;
    }

    public void addDTO(CommentDTO dto){
        list.add(dto);
    }

    public void delDTO(int position){
        list.remove(position);
    }

    @Override
    public int getCount(){
        return list.size();
    }

    @Override
    public CommentDTO getItem(int position){
        return list.get(position);
    }

    @Override
    public long getItemId(int position){
        return position;
    }

    public int getItemIdx(int position){
        CommentDTO dto = list.get(position);

        return dto.getCommentId();
    }

    @NonNull
    @Override
    public View getView(final int position, View convertView, ViewGroup parent){
        CommentAdapter.CommentViewHolder viewHolder;
        LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);

        if(convertView == null){
            convertView = inflater.inflate(R.layout.custom_comment, parent, false);
            viewHolder = new CommentAdapter.CommentViewHolder();

            viewHolder.user_id = convertView.findViewById(R.id.cmt_userid_tv);
            viewHolder.date = convertView.findViewById(R.id.cmt_date_tv);
            viewHolder.content = convertView.findViewById(R.id.cmt_content_tv);

            convertView.setTag(viewHolder);
        }else{
            viewHolder = (CommentAdapter.CommentViewHolder) convertView.getTag();
        }

        CommentDTO dto = list.get(position);

//        Log.d("test", dto.getTitle());

        TextView user_id = (TextView)convertView.findViewById(R.id.cmt_userid_tv);
        TextView date = (TextView)convertView.findViewById(R.id.cmt_date_tv);
        TextView content = (TextView)convertView.findViewById(R.id.cmt_content_tv);
        user_id.setText(dto.getCommentNickname());
        date.setText(dto.getCommentRegDate());
        content.setText(dto.getContent());
        Button btnCall = convertView.findViewById(R.id.CommentDelete_BTN);

        btnCall.setTag(position);

        btnCall.setOnClickListener(new Button.OnClickListener(){
            public void onClick(View v){
                if(listbtnclicklistener != null){
                    listbtnclicklistener.onListBtnClick((int)v.getTag());
                }
            }
        });

        if(!dto.getMyNickname().equals(dto.getCommentNickname())) {
            btnCall.setVisibility(View.GONE);
        }else{
            btnCall.setVisibility(View.VISIBLE);
        }





//        viewHolder.title.setText(dto.getTitle());

        return convertView;
    }

    public class CommentViewHolder{
        TextView user_id;
        TextView date;
        TextView content;

        Button delbtn;
    }
}
