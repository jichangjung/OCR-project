package com.example.myapplication;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.myapplication.DTO.UserDTO;
import com.example.myapplication.DTO.employeeDTO;
import com.example.myapplication.RetrofitClient;
import com.example.myapplication.UdatePwActivity;
import com.example.myapplication.UserRetrofitInterface;

import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class CheckNameActivity extends AppCompatActivity {

    EditText Name, Jumin;
    Button check;

    UserRetrofitInterface userRetrofitInterface;
    Intent intent, intent2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_find_id_pw);

        Name = findViewById(R.id.Name_Et);
        Jumin = findViewById(R.id.Jumin_Et);
        check = findViewById(R.id.update);
        intent = new Intent(CheckNameActivity.this, UdatePwActivity.class);
        intent2 = new Intent(CheckNameActivity.this, MainActivity.class);
        // Retrofit 인터페이스 초기화
        userRetrofitInterface = RetrofitClient.getInstance().getUserRetrofitInterface();

        check.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String InputName = Name.getText().toString();
                String InputJumin = Jumin.getText().toString();


                employeeDTO employee = new employeeDTO(InputName, InputJumin);

                Call<employeeDTO> call = userRetrofitInterface.sendUserData(employee);

                call.enqueue(new Callback<employeeDTO>() {
                    @Override
                    public void onResponse(Call<employeeDTO> call, Response<employeeDTO> response) {
                        if (response.isSuccessful()) {
                            // 성공적으로 서버로 데이터를 전송하고 응답을 받았을 때 실행할 로직을 추가하세요.
                            employeeDTO employee = response.body();

                            if(employee.getName() == null){
                                Toast.makeText(CheckNameActivity.this, "이름과 주민번호를 확인해주세요.", Toast.LENGTH_SHORT).show();
                            }else{
//                                Log.d("checkemployeeno", String.valueOf(employee.getNo()));
                                int no = employee.getNo();

                                Toast.makeText(CheckNameActivity.this, "새로운 비밀번호 입력.", Toast.LENGTH_SHORT).show();
                                intent.putExtra("no",no);
//                                Log.d("checkemployeeno", String.valueOf(no));
                                startActivity(intent);
                                finish();
                            }
                        } 
                    }

                    @Override
                    public void onFailure(Call<employeeDTO> call, Throwable t) {
                        // 통신 실패 시 실행할 로직을 추가하세요
                    }
                });
            }
        });

    }

    @Override
    public void onBackPressed() {
        startActivity(intent2);
        finish();
        super.onBackPressed();
    }
}