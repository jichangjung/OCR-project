package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.example.myapplication.Board.BoardActivity;

public class SelectActivity extends AppCompatActivity {
    Button MoveCommute,MoveBoard,MoveInfo;

    private int employeeNo;

    private String nickname;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_select);

        MoveCommute = findViewById(R.id.movecommute);
        MoveBoard = findViewById(R.id.moveboard);
        MoveInfo = findViewById(R.id.moveinfo);
        employeeNo = getIntent().getIntExtra("employeeNo", 0);

         nickname = getIntent().getStringExtra("nickname");


        MoveCommute.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent MoveCommute = new Intent(SelectActivity.this,CommuteCheck.class);
                MoveCommute.putExtra("employeeNo", employeeNo);
                startActivity(MoveCommute);
            }
        });

        MoveBoard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(SelectActivity.this, BoardActivity.class);
                intent.putExtra("nickname", nickname);
                startActivity(intent);

            }
        });


        MoveInfo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(SelectActivity.this,EmployeeInfo.class);
                startActivity(intent);
                finish();

            }
        });
       

    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }
}