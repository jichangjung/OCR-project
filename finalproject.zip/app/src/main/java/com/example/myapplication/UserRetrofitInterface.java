package com.example.myapplication;

import com.example.myapplication.DTO.AndroidWorkDTO;

import com.example.myapplication.DTO.JoinDTO; // JoinDTO 추가
import com.example.myapplication.DTO.UserDTO;
import com.example.myapplication.DTO.WorkDTO;
import com.example.myapplication.DTO.employeeDTO;

import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.GET;
import retrofit2.http.POST;

public interface
UserRetrofitInterface {



    @POST("/AndroidLogin")
    Call<UserDTO> LoginSend(@Body UserDTO user);

    @POST("save-user")
    Call<ResponseBody> saveUser(@Body JoinDTO joinDTO); // JoinDTO로 수정

    @POST("send-selected-date")
    Call<AndroidWorkDTO> sendSelectedDate(@Body WorkDTO workDTO); // 출석조회시 사용

    @POST("check")
    Call<ResponseBody>checkDuplicateId(@Body JoinDTO joinDTO);

    @POST("checkname")
    Call<employeeDTO> sendUserData(@Body employeeDTO employee);

    @POST("UpdatePw")
    Call<Boolean>updatePassword(@Body UserDTO pw);

    @POST("getNicknameByEmployeeNo")
    Call<UserDTO>getNicknameByEmployeeNo(@Body UserDTO user);

    @POST("employeeINFO")
    Call<employeeDTO>getInfo(@Body employeeDTO employeeinfo);

    @POST("UpdateEmployeeInfo")
    Call<Boolean>update(@Body employeeDTO update);


}
