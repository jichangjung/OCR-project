package com.example.myapplication;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.CalendarView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.example.myapplication.DTO.AndroidWorkDTO;
import com.example.myapplication.DTO.WorkDTO;
import com.google.gson.Gson;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class CommuteCheck extends AppCompatActivity {
    TextView diaryTextView, textView2, textView4,textView3;
    CalendarView calendarView;
    private UserRetrofitInterface userRetrofitInterface;
    private String workon;
    private int employeeNo; // 추가: employeeNo를 저장할 변수
    SharedPreferences sharedPreferences;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_commute_check);
        diaryTextView = findViewById(R.id.diaryTextView);
        textView2 = findViewById(R.id.textView2);
        calendarView = findViewById(R.id.calendarView);
        textView4 = findViewById(R.id.textView4);
        textView3 = findViewById(R.id.textView3);
        sharedPreferences = getSharedPreferences("UserInfo", MODE_PRIVATE);
        textView3.setVisibility(View.INVISIBLE);

        // Retrofit 인터페이스 초기화
        userRetrofitInterface = RetrofitClient.getInstance().getUserRetrofitInterface();

        employeeNo = sharedPreferences.getInt("employee_no",0);



        // "textView3"에 employeeNo 값을 설정


        calendarView.setOnDateChangeListener(new CalendarView.OnDateChangeListener() {
            @Override
            public void onSelectedDayChange(@NonNull CalendarView view, int year, int month, int dayOfMonth) {
                workon = String.format("%d-%02d-%02d", year, month + 1, dayOfMonth);

                diaryTextView.setText(workon);

                WorkDTO workDTO = new WorkDTO(workon,employeeNo);
                Gson gson = new Gson();
                String workDTOinfo = gson.toJson(workDTO);

                Call<AndroidWorkDTO> call = userRetrofitInterface.sendSelectedDate(workDTO);
                call.enqueue(new Callback<AndroidWorkDTO>() {
                    @Override
                    public void onResponse(Call<AndroidWorkDTO> call, Response<AndroidWorkDTO> response) {
                        if (response.isSuccessful()) {
                            AndroidWorkDTO androidWorkDTO = response.body();
                            if (androidWorkDTO != null) {
                                textView2.setVisibility(View.VISIBLE);
                                textView2.setText("출근시간 : "+androidWorkDTO.getWorkOn());
                                if(androidWorkDTO.getWorkOff()!=null) {
                                    textView4.setVisibility(View.VISIBLE);
                                    textView4.setText("퇴근시간 :" + androidWorkDTO.getWorkOff());
                                    String workoff = androidWorkDTO.getWorkOff();
                                }else{
                                    textView4.setVisibility(View.VISIBLE);
                                    textView4.setText("해당 날짜의 퇴근기록이 없습니다.");
                                }
                                } else {
                                textView2.setVisibility(View.VISIBLE);
                                textView2.setText("해당 날짜의 출근기록이 없습니다.");
                                textView4.setVisibility(View.VISIBLE);
                                textView4.setText("해당 날짜의 퇴근기록이 없습니다.");

                            }
                        }
                    }

                    @Override
                    public void onFailure(Call<AndroidWorkDTO> call, Throwable t) {
                        Log.e("POST", "실패");
                        textView2.setVisibility(View.VISIBLE);
                        textView2.setText("해당 날짜의 출근기록이 없습니다.");
                        textView4.setVisibility(View.VISIBLE);
                        textView4.setText("해당 날짜의 퇴근기록이 없습니다.");
                    }
                });
                // 나머지 코드...
            }
        });
    }

    @Override
    public void onBackPressed() {

        super.onBackPressed();
    }
}
