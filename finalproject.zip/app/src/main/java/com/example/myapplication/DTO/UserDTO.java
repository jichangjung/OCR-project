package com.example.myapplication.DTO;

public class UserDTO {


    private  int employeeNo;
    private String nickname;
    private String pw;

    private String jumin;
    private String name;

    public UserDTO(String pw,String nickname){
        this.pw=pw;
        this.nickname = nickname;
    }

    public UserDTO(int employeeNo) {
        this.employeeNo =employeeNo;
    }


    public String getJumin() {
        return jumin;
    }

    public void setJumin(String jumin) {
        this.jumin = jumin;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public UserDTO(String nickname, String pw, int employeeNo) {
        this.nickname = nickname;
        this.pw = pw;
        this.employeeNo = employeeNo;

    }


    public int getEmployee_no() {
        return employeeNo;
    }

    public void setEmployeeNo(int employeeNo) {
        this.employeeNo = employeeNo;
    }

    public String getNickname() {
        return nickname;
    }
    public int employeeNo(){
        return employeeNo;
    }

    public void setNickname(String nickname) {
        this.nickname = nickname;
    }

    public String getPw() {
        return pw;
    }

    public void setPw(String pw) {
        this.pw = pw;
    }
}
