package com.example.myapplication;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;


import com.example.myapplication.DTO.UserDTO;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainActivity extends AppCompatActivity {


    Button joinButton, LoginBtn, findID,openCameraButton;
    SharedPreferences sharedPreferences;


    UserRetrofitInterface userRetrofitInterface;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        openCameraButton = findViewById(R.id.openCameraButton);
        findID = findViewById(R.id.findID);
        EditText nickname = (EditText) findViewById(R.id.nicknameEditText);
        EditText pw = (EditText) findViewById(R.id.passwordEditText);
        LoginBtn = (Button) findViewById(R.id.login);
        joinButton = (Button) findViewById(R.id.Join);
        RetrofitClient retrofitClient = RetrofitClient.getInstance();
        userRetrofitInterface = RetrofitClient.getUserRetrofitInterface();
        sharedPreferences = getSharedPreferences("UserInfo", MODE_PRIVATE);

        LoginBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String inputNickname = nickname.getText().toString();
                String inputPassword = pw.getText().toString();
                int inputemployeeNo = 0;

                UserDTO userDTO = new UserDTO(inputNickname, inputPassword, inputemployeeNo);

                Call<UserDTO> call = userRetrofitInterface.LoginSend(userDTO);

                call.enqueue(new Callback<UserDTO>() {
                    @Override
                    public void onResponse(Call<UserDTO> call, Response<UserDTO> response) {
                        if (response.isSuccessful()) {
                            UserDTO loginUser = response.body();

                            if (loginUser != null) {
                                String userNickname = loginUser.getNickname();
                                int employee_no = loginUser.getEmployee_no();

                                SharedPreferences.Editor editor = sharedPreferences.edit();
                                //putString(KEY,VALUE)
                                editor.putString("nickname", userNickname);
                                editor.putInt("employee_no", employee_no);
                                editor.commit();
                                // 직원 번호를 토스트 메시지로 표시
                                String toastMessage = "로그인 성공: " + userNickname + " 직원번호 " + employee_no;
                                Toast.makeText(com.example.myapplication.MainActivity.this, toastMessage, Toast.LENGTH_SHORT).show();

                                Intent intent = new Intent(MainActivity.this, SelectActivity.class);
                                intent.putExtra("employeeNo", employee_no);
                                intent.putExtra("nickname", userNickname);
                                startActivity(intent);
                            }
                        } else {
                            // 서버로부터 null을 받을 경우 로그인 실패로 처리
                            Toast.makeText(com.example.myapplication.MainActivity.this, "로그인 실패", Toast.LENGTH_SHORT).show();
                        }
                    }

                    @Override
                    public void onFailure(Call<UserDTO> call, Throwable t) {
                        // 통신 실패 시도 처리
                        Toast.makeText(com.example.myapplication.MainActivity.this, "로그인 실패", Toast.LENGTH_SHORT).show();
                    }
                });
            }
        });


        joinButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(com.example.myapplication.MainActivity.this, JoinActivity.class);
                startActivity(intent);
                finish();
            }
        });
        findID.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, CheckNameActivity.class);
                startActivity(intent);
                finish();
            }
        });


        openCameraButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                dispatchTakePictureIntent();

            }
        });
    }


    private void dispatchTakePictureIntent() {
        Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        if (takePictureIntent.resolveActivity(getPackageManager()) != null) {
            startActivityForResult(takePictureIntent, 0); // requestCode를 0으로 설정
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 0 && resultCode == RESULT_OK) {
            // 사진이 성공적으로 찍힌 경우
            Intent intent = new Intent(this, UploadActivity.class);
            startActivity(intent);
            finish();
        }
    }
}
