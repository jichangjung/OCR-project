package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.myapplication.DTO.UserDTO;
import com.example.myapplication.DTO.employeeDTO;

import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class UdatePwActivity extends AppCompatActivity {

    TextView nickname_TV;
    EditText Pw_ET;

    Button Update_Pw, idtest;

    UserRetrofitInterface userRetrofitInterface;

    // 직원 번호를 저장하는 변수
    int employee_no;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_udate_pw);

        nickname_TV = findViewById(R.id.nickname_Et);
        Pw_ET = findViewById(R.id.Pw_ET);
        Update_Pw = findViewById(R.id.Update_Pw);

        // 직원 번호를 인텐트에서 가져오기
        employee_no = getIntent().getIntExtra("no", 0);
        Log.d("employeeno update", String.valueOf(employee_no));

        // Retrofit 초기화 및 UserRetrofitInterface 생성
        userRetrofitInterface = RetrofitClient.getInstance().getUserRetrofitInterface();



                // UserDTO 객체 생성 및 employee_no 설정
                UserDTO user = new UserDTO(employee_no);

                // Retrofit을 사용하여 'employee_no'를 서버로 전송
                Call<UserDTO> call = userRetrofitInterface.getNicknameByEmployeeNo(user);
                call.enqueue(new Callback<UserDTO>() {
                    @Override
                    public void onResponse(Call<UserDTO> call, Response<UserDTO> response) {
                        if (response.isSuccessful()) {
                            UserDTO userInfo = response.body();
                            String id =userInfo.getNickname();
                            nickname_TV.setText(id);
                            // 서버에서 받아온 직원 정보를 사용하거나 표시할 수 있습니다.
                            // 예를 들어, userInfo.getNickname()로 닉네임을 가져올 수 있습니다.
                        } else {
                            // 요청이 실패하거나 오류를 처리합니다.
                        }
                    }

                    @Override
                    public void onFailure(Call<UserDTO> call, Throwable t) {
                        // 네트워크 오류를 처리합니다.
                    }
                });





        Update_Pw.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Pw_ET에서 비밀번호 가져오기
                String Pw = Pw_ET.getText().toString();
                String Id = nickname_TV.getText().toString();
                Log.d("id",Id);
                // UserDTO 객체 생성
                UserDTO user = new UserDTO(Pw,Id);

                // 직원 번호 설정
                user.setEmployeeNo(employee_no);

                // Retrofit을 사용하여 UserDTO 객체를 서버로 전송
                Call<Boolean> call = userRetrofitInterface.updatePassword(user);
                call.enqueue(new Callback<Boolean>() {
                    @Override
                    public void onResponse(Call<Boolean> call, Response<Boolean> response) {
                        Log.d("update","aa");
                        if (response.isSuccessful()) {
                            Boolean chk = response.body();
                            if(chk){
                                Toast.makeText(UdatePwActivity.this, "비밀번호 변경이 완료되었습니다.", Toast.LENGTH_SHORT).show();
                                Intent intent = new Intent(UdatePwActivity.this,MainActivity.class);

                                startActivity(intent);
                                finish();
                            }else{

                            }
                            Log.d("update","bbbbbbbbbbbbbb");

                        } else {

                        }
                    }

                    @Override
                    public void onFailure(Call<Boolean> call, Throwable t) {
                        // 네트워크 오류 처리
                    }
                });
            }
        });
    }


}
