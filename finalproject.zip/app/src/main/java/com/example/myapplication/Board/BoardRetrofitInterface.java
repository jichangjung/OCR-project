package com.example.myapplication.Board;

import com.example.myapplication.DTO.BoardDTO;
import com.example.myapplication.DTO.CommentDTO;

import java.util.List;

import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.GET;
import retrofit2.http.POST;
import retrofit2.http.Path;

public interface BoardRetrofitInterface {
    @GET("board")
    Call<List<BoardDTO>> getBoard();


    @POST("board.do")
    Call<ResponseBody> doBoard(@Body BoardDTO boardData);

    @POST("CreatePost1")
    Call<ResponseBody> saveTest(@Body BoardDTO BoardDTO);

    @POST("CreateComment")
    Call<ResponseBody>createComment(@Body CommentDTO commentDTO);

    @POST("board.delete/{postIdx}")
    Call<ResponseBody> deleteBoard(@Path("postIdx") int postIdx);

    @POST("board.update")
    Call<ResponseBody> updateBoard(@Body BoardDTO boardData);

    @GET("board/comments/{postIdx}")
    Call<List<CommentDTO>> getCommentsByBoardIdx(@Path("postIdx") int postIdx);

    @POST("DeleteComment")
    Call<Boolean> deleteComment(@Body CommentDTO commentdelete);
}

