package com.example.myapplication.DTO;

public class WorkDTO {
    //private String send; // send 변수 추가
    private int no;      // 직원 번호
    private String workOn;       // 작업 시작 시간
    private String workOff;      // 작업 종료 시간




    public WorkDTO(String workOn, int no) {

        this.no = no;
        this.workOn = workOn;
        this.workOff = workOff;
    }


    public int getEmployeeNo() {
        return no;
    }

    public void setEmployeeNo(int employeeNo) {
        this.no = employeeNo;
    }

    public String getWorkOn() {
        return workOn;
    }

    public void setWorkOn(String workOn) {
        this.workOn = workOn;
    }

    public String getWorkOff() {
        return workOff;
    }

    public void setWorkOff(String workOff) {
        this.workOff = workOff;
    }
}
