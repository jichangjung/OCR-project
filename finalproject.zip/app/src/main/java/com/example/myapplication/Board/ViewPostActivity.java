package com.example.myapplication.Board;

import android.app.Activity;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.PopupMenu;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import com.example.myapplication.Adapter.BoardAdapter;
import com.example.myapplication.Adapter.CommentAdapter;
import com.example.myapplication.Board.BoardRetrofitInterface;
import com.example.myapplication.Board.UpdatePostActivity;
import com.example.myapplication.DTO.BoardDTO;
import com.example.myapplication.DTO.CommentDTO;
import com.example.myapplication.Board.UpdatePostActivity;
import com.example.myapplication.R;
import com.example.myapplication.RetrofitClient;

import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class ViewPostActivity extends AppCompatActivity implements CommentAdapter.ListBtnClickListener {

    private String nickname;

    private ListView listView;

    private CommentAdapter adapter;
    private ArrayList<CommentDTO> PostList;

    private TextView titleTextView, contentTextView, nicknameTextView;

    private Button CommentCreateBTN, overflowButton,CommentDeleteBTN,  commentDeleteBtn ;

    private BoardRetrofitInterface boardRetrofitInterface;

    private EditText comment_et;



    @RequiresApi(api = Build.VERSION_CODES.O)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_post);
        listView = findViewById(R.id.comment_listview);
        boardRetrofitInterface = RetrofitClient.getInstance().getBoardRetrofitInterface();
        nickname = getIntent().getStringExtra("nickname");
        titleTextView = findViewById(R.id.title_tv);
        contentTextView = findViewById(R.id.content_tv);
        nicknameTextView = findViewById(R.id.nick);
        CommentCreateBTN = findViewById(R.id.CommentCreateBTN);
        comment_et = findViewById(R.id.comment_et);

        // custom_comment.xml 레이아웃을 인플레이트한 뷰 객체를 생성하고, 해당 뷰에서 삭제 버튼을 찾습니다.
        View customCommentView = getLayoutInflater().inflate(R.layout.custom_comment, null);
         commentDeleteBtn = customCommentView.findViewById(R.id.CommentDelete_BTN);

        int postidx = getIntent().getIntExtra("post_idx", 0);
        String postTitle = getIntent().getStringExtra("post_title");
        String postContent = getIntent().getStringExtra("post_content");
        String postNickname = getIntent().getStringExtra("post_nickname"); // 닉네임 정보 가져오기

        titleTextView.setText(postTitle);
        contentTextView.setText(postContent);
        nicknameTextView.setText(postNickname); // 닉네임 설정

        // 댓글 목록을 가져오는 메서드 호출
        loadComments(postidx);
//        commentDeleteBtn.setOnClickListener(mOnClickListener);
//        commentDeleteBtn.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                // 댓글 삭제 요청을 서버에 보내는 부분
//
//            }
//        });

        CommentCreateBTN.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String comment = comment_et.getText().toString();
                CommentDTO commentDTO = new CommentDTO(comment);
                commentDTO.setNickname(nickname, postidx); // 닉네임을 CommentDTO 객체에 설정

                Call<ResponseBody> call = boardRetrofitInterface.createComment(commentDTO);

                call.enqueue(new Callback<ResponseBody>() {
                    @Override
                    public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
                        if (response.isSuccessful()) {
                            // 댓글 작성 성공
                            // 성공 처리 로직을 추가하세요
                            Log.d("CommentCreate", "댓글 작성 성공");
                            // 댓글을 작성한 후, 댓글 목록을 다시 가져올 수 있도록 아래 코드를 추가
                            loadComments(postidx);
                            comment_et.setText("");
                        } else {
                            // 댓글 작성 실패
                            // 실패 처리 로직을 추가하세요
                            Log.d("CommentCreate", "댓글 작성 실패");
                        }
                    }

                    @Override
                    public void onFailure(Call<ResponseBody> call, Throwable t) {
                        // 통신 실패 처리
                        // 실패 처리 로직을 추가하세요
                        Log.e("CommentCreate", "댓글 작성 통신 실패: " + t.getMessage());
                    }
                });
            }
        });


        overflowButton = findViewById(R.id.overflowButton);
        overflowButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showPopupMenu(view);
            }
        });

    }
    @Override
    public void onListBtnClick(int position){
        CommentDTO dto = adapter.getItem(position);
        Log.d("position", String.valueOf(dto.getCommentId()));
        Call<Boolean> call = boardRetrofitInterface.deleteComment(dto);

        call.enqueue(new Callback<Boolean>() {
            @RequiresApi(api = Build.VERSION_CODES.O)
            @Override
            public void onResponse(Call<Boolean> call, Response<Boolean> response) {
                if (response.isSuccessful()) {
                    Boolean res = response.body();
                    if(res){
                        Log.d("CommentDelete", "댓글 삭제 성공");
                        loadComments(dto.getBoardIdx());
                    }else{
                        Log.d("CommentDelete", "댓글 삭제 실패");
                    }
                } else {
                            // 댓글 삭제 실패
                            // 실패 처리 로직을 추가하세요
                    Log.d("CommentDelete", "댓글 삭제 실패");
                }
            }

            @Override
            public void onFailure(Call<Boolean> call, Throwable t) {
                // 통신 실패 처리
                // 실패 처리 로직을 추가하세요
                Log.e("CommentDelete", "댓글 삭제 통신 실패: " + t.getMessage());
            }
        });
    }
    // 댓글 목록을 가져오는 메서드
    @RequiresApi(api = Build.VERSION_CODES.O)
    private void loadComments(int postidx) {
        LinearLayout commentLayout = findViewById(R.id.comment_layout);

        PostList = new ArrayList<>();

        adapter = new CommentAdapter(this, PostList, this );

        // 서버에서 댓글 데이터를 가져오는 API를 호출
        Call<List<CommentDTO>> call = boardRetrofitInterface.getCommentsByBoardIdx(postidx); // 필요한 파라미터를 전달

        call.enqueue(new Callback<List<CommentDTO>>() {
            @Override
            public void onResponse(Call<List<CommentDTO>> call, Response<List<CommentDTO>> response) {
                if (response.isSuccessful()) {
//                    commentLayout.removeAllViews();
                    List<CommentDTO> comments = response.body();

                    for (CommentDTO comment : comments) {
//                        View commentView = getLayoutInflater().inflate(R.layout.custom_comment, null);
//
//                        TextView userIdTextView = commentView.findViewById(R.id.cmt_userid_tv);
//                        TextView dateTextView = commentView.findViewById(R.id.cmt_date_tv);
//                        TextView contentTextView = commentView.findViewById(R.id.cmt_content_tv);
//
//                        String commentid =comment.getCommentId();
//                        userIdTextView.setText(""+comment.getCommentNickname());
//                        dateTextView.setText(comment.getCommentRegDate().toString());
//                        contentTextView.setText(comment.getContent());
//                        commentLayout.addView(commentView);
                        comment.setMyNickName(nickname);
                        Log.d("position2", String.valueOf(comment.getCommentId()));
                        adapter.addDTO(comment);

                    }
                    listView.setAdapter(adapter);
                    setListViewHeightBasedOnChildren(listView);
                } else {
                    // 댓글 데이터를 가져오지 못한 경우에 대한 처리
                    Log.e("loadCommentsNoOne", "댓글 데이터 가져오기 실패");
                }
            }

            @Override
            public void onFailure(Call<List<CommentDTO>> call, Throwable t) {
                // 통신 실패 처리
                Log.e("loadCommentsFailure", "댓글 데이터 가져오기 실패: " + t.getMessage());
            }
        });
    }


    private void displayComments(List<CommentDTO> comments) {
        LinearLayout commentLayout = findViewById(R.id.comment_layout);

        for (CommentDTO comment : comments) {
            View commentView = getLayoutInflater().inflate(R.layout.custom_comment, null);

            TextView userIdTextView = commentView.findViewById(R.id.cmt_userid_tv);
            TextView dateTextView = commentView.findViewById(R.id.cmt_date_tv);
            TextView contentTextView = commentView.findViewById(R.id.cmt_content_tv);


            userIdTextView.setText(String.valueOf(comment.getCommentId()));
            dateTextView.setText(comment.getCommentRegDate().toString());
            contentTextView.setText(comment.getContent());
            commentLayout.addView(commentView);
        }
    }



    public static void setListViewHeightBasedOnChildren(ListView listView) {
        ListAdapter listAdapter = listView.getAdapter();
        if (listAdapter == null) {
            // pre-condition
            return;
        }

        int totalHeight = 0;

        int desiredWidth = View.MeasureSpec.makeMeasureSpec(listView.getWidth(), View.MeasureSpec.AT_MOST);
        for (int i = 0; i < listAdapter.getCount(); i++) {
            View listItem = listAdapter.getView(i, null, listView);
            //listItem.measure(0, 0);
            listItem.measure(desiredWidth, View.MeasureSpec.UNSPECIFIED);
            totalHeight += listItem.getMeasuredHeight();
        }
        ViewGroup.LayoutParams params = listView.getLayoutParams();

        params.height = totalHeight;
        listView.setLayoutParams(params);

        listView.requestLayout();
    }




    private void showPopupMenu(View view) {
        PopupMenu popupMenu = new PopupMenu(this, view);
        popupMenu.getMenuInflater().inflate(R.menu.overflow_menu, popupMenu.getMenu());

        boolean canEditOrDelete = nicknameTextView.getText().toString().equals(nickname);

        for (int i = 0; i < popupMenu.getMenu().size(); i++) {
            MenuItem menuItem = popupMenu.getMenu().getItem(i);
            if (menuItem.getItemId() == R.id.option1) {
                if (canEditOrDelete) {
                    menuItem.setEnabled(true);
                } else {
                    menuItem.setEnabled(false);
                }
            }
        }

        popupMenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem menuItem) {
                int id = menuItem.getItemId();

                if (id == R.id.option1 && canEditOrDelete) {
                    Intent intent = new Intent(ViewPostActivity.this, UpdatePostActivity.class);
                    nickname = getIntent().getStringExtra("nickname");
                    intent.putExtra("nickname", nickname);
                    int postidx = getIntent().getIntExtra("post_idx", 0);
                    String postTitle = getIntent().getStringExtra("post_title");
                    String postContent = getIntent().getStringExtra("post_content");
                    String postNickname = getIntent().getStringExtra("post_nickname");
                    intent.putExtra("post_idx",postidx);
                    intent.putExtra("post_title", postTitle);
                    intent.putExtra("post_content", postContent);
                    intent.putExtra("post_nickname", postNickname);

                    startActivity(intent);
                    finish();
                    Toast.makeText(ViewPostActivity.this, "수정 삭제 하기", Toast.LENGTH_SHORT).show();

                } else {
                    Toast.makeText(ViewPostActivity.this, "권한이 없습니다.", Toast.LENGTH_SHORT).show();
                }
                return true;
            }
        });

        popupMenu.show();
    }

    @Override
    public void onBackPressed() {
        Intent intent = new Intent(ViewPostActivity.this,BoardActivity.class);
        startActivity(intent);
        super.onBackPressed();

    }
}
