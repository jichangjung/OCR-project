package com.example.myapplication.DTO;

public class JoinDTO {
    private String employeeNo;
    private String nickname;
    private String pw;


    public JoinDTO(String employeeNo, String nickname, String pw) {
        this.employeeNo = employeeNo;
        this.nickname = nickname;
        this.pw = pw;
    }

    public JoinDTO(String nickname) {
        this.nickname = nickname;
    }




    public String getEmployeeNo() {
        return employeeNo;
    }

    public void setEmployeeNo(String employeeNo) {
        this.employeeNo = employeeNo;
    }

    public String getNickname() {
        return nickname;
    }

    public void setNickname(String nickname) {
        this.nickname = nickname;
    }

    public String getPw() {
        return pw;
    }

    public void setPw(String pw) {
        this.pw = pw;
    }
}
