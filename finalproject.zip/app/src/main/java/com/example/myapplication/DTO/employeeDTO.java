package com.example.myapplication.DTO;

public class employeeDTO {
    private String name;
    private String juminNum;

    private String telNum;

    private String email;
    private   int   no;

    public String jikup;

    public int getNo() {
        return no;
    }

    public String getTelNum() {
        return telNum;
    }

    public void setTelNum(String telNum) {
        this.telNum = telNum;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setNo(int no) {
        this.no = no;
    }

    public String getName() {
        return name;
    }

    public String getJikup() {
        return jikup;
    }

    public void setJikup(String jikup) {
        this.jikup = jikup;
    }

    public employeeDTO(String name, String juminNum) {
        this.name = name;
        this.juminNum = juminNum;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getJuminNum() {
        return juminNum;
    }

    public void setJuminNum(String juminNum) {
        this.juminNum = juminNum;
    }

    public employeeDTO(int no) {
        this.no = no;
    }

    public employeeDTO(int   no, String telNum, String email) {
        this.no=no;
        this.telNum = telNum;
        this.email = email;
    }
}
