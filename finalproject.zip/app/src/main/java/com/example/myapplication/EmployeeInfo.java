package com.example.myapplication;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.myapplication.DTO.employeeDTO;
import com.example.myapplication.RetrofitClient;
import com.example.myapplication.UserRetrofitInterface;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class EmployeeInfo extends AppCompatActivity {

    TextView name, jumin, employeeno, jikup;
    EditText telnum, email;
    Button updateInfo; // Renamed to match XML layout

    SharedPreferences sharedPreferences;
    UserRetrofitInterface userRetrofitInterface;
    private int employeeNo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_employee_info);

        sharedPreferences = getSharedPreferences("UserInfo", MODE_PRIVATE);
        employeeNo = sharedPreferences.getInt("employee_no", 0);

        userRetrofitInterface = RetrofitClient.getInstance().getUserRetrofitInterface();
        name = findViewById(R.id.name);
        jumin = findViewById(R.id.jumin);
        telnum = findViewById(R.id.tel_num);
        email = findViewById(R.id.email);
        employeeno = findViewById(R.id.dep_no);
        jikup = findViewById(R.id.jickup);

        // UpdateInfo button was not initialized in your code, let's initialize it
        updateInfo = findViewById(R.id.updateInfo);

        // "employeeno" 값을 TextView에 표시
        employeeno.setText("직원번호: " + String.valueOf(employeeNo));

        // Fetch and display employee information
        fetchAndDisplayEmployeeInfo();

        updateInfo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String getemail = email.getText().toString();
                String gettelnum = telnum.getText().toString();
                employeeDTO update = new employeeDTO(employeeNo, gettelnum, getemail);

                // Retrofit을 사용하여 업데이트된 정보를 서버로 전송
                Call<Boolean> updateCall = userRetrofitInterface.update(update);
                updateCall.enqueue(new Callback<Boolean>() {
                    @Override
                    public void onResponse(Call<Boolean> call, Response<Boolean> response) {
                        if (response.isSuccessful()) {
                            Boolean ue = response.body();
                            if (ue) {
                                Toast.makeText(EmployeeInfo.this, "직원 정보 변경 성공.", Toast.LENGTH_SHORT).show();
                                Intent intent = new Intent(EmployeeInfo.this,SelectActivity.class);
                                startActivity(intent);
                                finish();

                            } else {
                                Toast.makeText(EmployeeInfo.this, "직원 정보 변경 성공 실패", Toast.LENGTH_SHORT).show();
                            }
                        } else {
                            // Handle update request failure
                            Toast.makeText(EmployeeInfo.this, "Network error", Toast.LENGTH_SHORT).show();
                        }
                    }

                    @Override
                    public void onFailure(Call<Boolean> call, Throwable t) {
                        // Handle network error during update
                        Toast.makeText(EmployeeInfo.this, "Network error", Toast.LENGTH_SHORT).show();
                    }
                });
            }
        });
    }

    private void fetchAndDisplayEmployeeInfo() {
        employeeDTO user = new employeeDTO(employeeNo);

        // Retrofit을 사용하여 'employee_no'를 서버로 전송
        Call<employeeDTO> call = userRetrofitInterface.getInfo(user);
        call.enqueue(new Callback<employeeDTO>() {
            @Override
            public void onResponse(Call<employeeDTO> call, Response<employeeDTO> response) {
                if (response.isSuccessful()) {
                    employeeDTO userInfo = response.body();
                    Log.d("userinfo", userInfo.toString());

                    String getname = userInfo.getName();
                    String getjumin = userInfo.getJuminNum();
                    String getemail = userInfo.getEmail();
                    String gettelnum = userInfo.getTelNum();
                    String getjikup = userInfo.getJikup();

                    name.setText(getname);
                    jumin.setText(getjumin);
                    email.setText(getemail);
                    telnum.setText(gettelnum);
                    jikup.setText(getjikup);
                } else {
                    // Handle request failure
                    Toast.makeText(EmployeeInfo.this, "Failed to fetch employee info", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<employeeDTO> call, Throwable t) {
                // Handle network error
                Toast.makeText(EmployeeInfo.this, "Network error", Toast.LENGTH_SHORT).show();
            }
        });
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        Intent intent = new Intent(EmployeeInfo.this,SelectActivity.class);
        startActivity(intent);
        finish();
    }
}
